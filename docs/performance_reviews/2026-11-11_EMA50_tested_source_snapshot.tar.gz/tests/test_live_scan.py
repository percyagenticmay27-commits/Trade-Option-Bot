from datetime import datetime
from decimal import Decimal
from pathlib import Path
from zoneinfo import ZoneInfo

import pytest

from option_bot.domain import (
    Decision, ExerciseStyle, Money, OptionLeg, OptionRight, ProductMetadata,
    SettlementType, StructureType, TradeCandidate, TradeSide,
)
from option_bot.evidence import EvidenceBundle
from option_bot.live_scan import (
    EvaluatedSetup, SetupEvaluator, _exposure_group, _market_history_start,
    _resolve_option_surface, build_scan_report, evaluate_live_scan,
)
from option_bot.portfolio import SelectableCandidate
from option_bot.providers.base import Availability, EventGateEvidence, OptionSurface
from option_bot.indicators import IndicatorSnapshot


ET = ZoneInfo("America/New_York")


def test_market_history_start_includes_prior_completed_sessions() -> None:
    """Catches near-open scans requesting only same-day bars and always lacking indicator history."""
    as_of = datetime(2026, 9, 16, 9, 45, tzinfo=ET)
    start = _market_history_start(as_of)
    assert start < as_of
    assert (as_of.date() - start.date()).days >= 5
    assert start.hour == 4 and start.minute == 0


def test_scan_report_uses_evaluated_setups_instead_of_placeholder_rows(tmp_path: Path) -> None:
    """Catches scan wiring that discards evaluator output and emits blanket DATA_UNAVAILABLE."""
    candidate = SelectableCandidate(
        "AAPL", "AAPL-PUT_CREDIT_SPREAD-0.10", StructureType.PUT_CREDIT_SPREAD,
        Decimal("82"), Decimal("90"), "MEGA_CAP_TECH",
    )
    setup = EvaluatedSetup(
        symbol="AAPL", decision=Decision.TRADE, candidate=candidate,
        direction_score=82, range_score=0, premium_score=70,
        expected_value=Decimal("18.50"), reason_codes=(), evidence_id="scan:AAPL",
    )

    bundle = build_scan_report(
        trade_date="2026-09-15", symbols=("AAPL", "MSFT"),
        evaluations=(setup, EvaluatedSetup.unavailable("MSFT", ("STALE_QUOTES",))),
        output_dir=tmp_path, render=False,
    )

    assert bundle.leaderboard[0]["decision"] == "TRADE"
    assert bundle.leaderboard[0]["structure"] == "PUT_CREDIT_SPREAD"
    assert bundle.leaderboard[0]["expected_value"] == "18.50"
    assert bundle.leaderboard[1]["decision"] == "DATA_UNAVAILABLE"
    assert bundle.summary["selected_count"] == 1
    assert bundle.summary["health"] == "DEGRADED"


def test_scan_report_records_valid_no_trade_as_evaluated_not_pending(tmp_path: Path) -> None:
    """Catches valid rejected setups being mislabeled as missing provider data."""
    setup = EvaluatedSetup(
        symbol="AAPL", decision=Decision.NO_TRADE, candidate=None,
        direction_score=42, range_score=20, premium_score=70,
        expected_value=None, reason_codes=("SCORE_BELOW_THRESHOLD",), evidence_id="scan:AAPL",
    )
    bundle = build_scan_report(
        trade_date="2026-09-15", symbols=("AAPL",), evaluations=(setup,),
        output_dir=tmp_path, render=False,
    )
    assert bundle.leaderboard[0]["status"] == "EVALUATED"
    assert bundle.leaderboard[0]["decision"] == "NO_TRADE"
    assert bundle.summary["health"] == "HEALTHY"


def test_setup_evaluator_distinguishes_missing_evidence_from_rejected_structures() -> None:
    """Catches the composition layer mapping every non-trade outcome to DATA_UNAVAILABLE."""
    evidence = EvidenceBundle(True, 60, 0, 70, Decimal("1"), "v1", "hash", (), None, None)
    evaluator = SetupEvaluator(
        score=lambda *_: evidence,
        generate=lambda *_: (),
        trade_threshold=75,
        watch_threshold=55,
        max_loss=Decimal("100"),
    )
    indicators = IndicatorSnapshot(
        True, Decimal("200"), Decimal("199"), Decimal("200"), Decimal("199"),
        25, 40, 2, 1.2, Decimal("201"), Decimal("198"), Decimal("202"),
        Decimal("195"), 2, False,
    )
    events = EventGateEvidence("AAPL", Availability.AVAILABLE, False, ())

    result = evaluator.evaluate("AAPL", indicators, OptionSurface("AAPL", "2026-09-15", (), "indicative", Availability.AVAILABLE), events)

    assert result.decision is Decision.WATCH
    assert result.direction_score == 60
    assert "NO_VALID_STRUCTURE" in result.reason_codes


def test_setup_evaluator_scores_debit_candidates(tmp_path: Path) -> None:
    """Catches debit structures being generated but silently discarded before ranking."""
    expiry = "2026-09-15"
    product = ProductMetadata("AAPL", 100, ExerciseStyle.AMERICAN, SettlementType.PHYSICAL, "16:00")
    candidate = TradeCandidate(
        "AAPL-CALL_DEBIT_SPREAD-0.20",
        "AAPL",
        (
            OptionLeg("AAPL-C100", OptionRight.CALL, TradeSide.BUY, Decimal("100"), expiry, 1),
            OptionLeg("AAPL-C105", OptionRight.CALL, TradeSide.SELL, Decimal("105"), expiry, 1),
        ),
        product,
        structure_type=StructureType.CALL_DEBIT_SPREAD,
        net_debit=Money(Decimal("2.00")),
        probability_of_profit=Decimal(".80"), probability_model_version="test-verified",
    )
    evidence = EvidenceBundle(True, 90, 20, 80, Decimal("1"), "v1", "hash", (), None, None)
    evaluator = SetupEvaluator(
        score=lambda *_: evidence,
        generate=lambda *_: (candidate,),
        trade_threshold=75,
        watch_threshold=55,
        max_loss=Decimal("500"),
    )
    indicators = IndicatorSnapshot(
        True, Decimal("200"), Decimal("199"), Decimal("200"), Decimal("199"),
        25, 40, 2, 1.2, Decimal("201"), Decimal("198"), Decimal("202"),
        Decimal("195"), 2, False,
    )
    result = evaluator.evaluate(
        "AAPL", indicators,
        OptionSurface("AAPL", expiry, (), "indicative", Availability.AVAILABLE),
        EventGateEvidence("AAPL", Availability.AVAILABLE, False, ()),
    )
    assert result.decision is Decision.TRADE
    assert result.candidate.structure_type is StructureType.CALL_DEBIT_SPREAD
    assert result.candidate.maximum_loss == Decimal("200.00")
    assert result.candidate.maximum_profit == Decimal("300.00")
    assert result.candidate.premium_type == "DEBIT"
    assert result.candidate.entry_price == Decimal("2.00")

    report = build_scan_report(
        trade_date=expiry, symbols=("AAPL",), evaluations=(result,),
        output_dir=tmp_path, render=False,
    )
    selected = report.positions["selected"][0]
    assert selected["premium_type"] == "DEBIT"
    assert selected["entry_price"] == "2.00"
    assert selected["maximum_profit"] == "300.00"
    assert selected["maximum_loss"] == "200.00"


def test_scan_report_applies_two_entry_and_daily_defined_loss_limits(tmp_path: Path) -> None:
    """Catches qualified rows bypassing portfolio limits when reports mark selections."""
    setups = []
    for symbol, score in (("AAPL", "90"), ("TSLA", "85"), ("DJX", "80")):
        candidate = SelectableCandidate(symbol, f"{symbol}-candidate", StructureType.PUT_CREDIT_SPREAD, Decimal(score), Decimal("90"), symbol)
        setups.append(EvaluatedSetup(symbol, Decision.TRADE, candidate, 90, 0, 70, Decimal("10"), (), f"scan:{symbol}"))
    bundle = build_scan_report(trade_date="2026-09-15", symbols=("AAPL", "TSLA", "DJX"), evaluations=tuple(setups), output_dir=tmp_path, render=False)
    assert bundle.summary["selected_count"] == 2
    assert [row["symbol"] for row in bundle.positions["selected"]] == ["AAPL", "TSLA"]


def test_spx_and_xsp_share_one_index_exposure_group() -> None:
    """Catches simultaneous SPX and XSP selection despite the one-position rule."""
    assert _exposure_group("SPX") == "SPX_XSP_INDEX"
    assert _exposure_group("XSP") == "SPX_XSP_INDEX"


def test_scan_report_ranks_evaluated_setups_by_score(tmp_path: Path) -> None:
    """Catches the leaderboard retaining config order instead of evidence rank."""
    low = EvaluatedSetup("AAPL", Decision.WATCH, None, 55, 0, 70, None, ("NO_VALID_STRUCTURE",), "a")
    high = EvaluatedSetup("MSFT", Decision.NO_TRADE, None, 70, 0, 70, None, ("NO_VALID_STRUCTURE",), "m")
    bundle = build_scan_report(trade_date="2026-09-15", symbols=("AAPL", "MSFT"), evaluations=(low, high), output_dir=tmp_path, render=False)
    assert [row["symbol"] for row in bundle.leaderboard] == ["MSFT", "AAPL"]
    assert [row["rank"] for row in bundle.leaderboard] == [1, 2]


def test_read_only_robinhood_research_fills_missing_alpaca_greeks():
    # Catches the scan stopping at Alpaca MISSING_GREEKS despite fresh research evidence.
    primary = OptionSurface(
        "AAPL", "2026-09-16", (), "indicative", Availability.UNAVAILABLE,
        ("MISSING_GREEKS",),
    )
    research = OptionSurface(
        "AAPL", "2026-09-16", (), "robinhood_mcp_research",
        Availability.AVAILABLE, evidence={
            "research_only": "true",
            "order_submission_enabled": "false",
        },
    )
    calls = []

    selected = _resolve_option_surface(
        primary,
        lambda symbol, expiration, as_of: (
            calls.append((symbol, expiration)) or research
        ),
        datetime(2026, 9, 16, 10, 0, tzinfo=ET),
    )

    assert selected is research
    assert calls == [("AAPL", "2026-09-16")]


@pytest.mark.parametrize(
    ("contract_status", "contract_payload"),
    ((422, {}), (200, {"option_contracts": []})),
)
def test_robinhood_research_can_rescue_missing_alpaca_contract_surface(
    monkeypatch, contract_status, contract_payload,
):
    """Catches early Alpaca exits preventing complete read-only research evidence."""
    research = OptionSurface(
        "SPX", "2026-09-17", (), "robinhood_mcp_research",
        Availability.AVAILABLE, evidence={
            "research_only": "true",
            "order_submission_enabled": "false",
        },
    )
    calls = []
    market_calls = []
    monkeypatch.setattr(
        SetupEvaluator,
        "evaluate",
        lambda self, symbol, indicators, surface, events, config: EvaluatedSetup(
            symbol, Decision.NO_TRADE, None, 60, 0, 70, None,
            ("NO_VALID_STRUCTURE",), f"scan:{symbol}",
        ),
    )
    monkeypatch.setattr(
        "option_bot.live_scan.IndicatorEngine.compute",
        lambda *args, **kwargs: IndicatorSnapshot(
            True, Decimal("7600"), Decimal("7590"), Decimal("7600"), Decimal("7590"),
            25, 40, 20, 0.5, Decimal("7610"), Decimal("7580"), Decimal("7620"),
            Decimal("7570"), 2, False, ema50=Decimal("7595"), ema50_slope=Decimal("0.5"),
        ),
    )

    results = evaluate_live_scan(
        symbols=("SPX",), trade_date="2026-09-17",
        as_of=datetime(2026, 9, 17, 10, 0, tzinfo=ET),
        paper_transport=lambda *_: (contract_status, contract_payload),
        market_transport=lambda method, path, params, body: (
            market_calls.append(path) or (200, {"bars": []})
        ),
        event_report={"scheduled_calendar_status": "AVAILABLE", "event_gate": "CLEAR"},
        evidence_engine=type("Engine", (), {"score": lambda *args: None})(),
        max_loss=Decimal("100"),
        trade_threshold=75, watch_threshold=55,
        research_surface_provider=lambda symbol, expiration, as_of: (
            calls.append((symbol, expiration)) or research
        ),
    )

    assert results[0].decision is Decision.NO_TRADE
    assert results[0].reason_codes == ("NO_VALID_STRUCTURE",)
    assert calls == [("SPX", "2026-09-17")]
    assert "/v2/stocks/SPY/bars" in market_calls


def test_missing_robinhood_research_preserves_primary_unavailable_surface():
    """Missing optional research must fail closed, not crash the whole scan."""
    primary = OptionSurface(
        "AAPL", "2026-09-16", (), "indicative", Availability.UNAVAILABLE,
        ("MISSING_GREEKS",),
    )

    selected = _resolve_option_surface(
        primary,
        lambda _symbol, _expiration, _as_of: None,
        datetime(2026, 9, 16, 10, 0, tzinfo=ET),
    )

    assert selected is primary


def test_robinhood_only_scan_never_calls_alpaca_transports(monkeypatch):
    """Catches a Robinhood-only scan still querying Alpaca contracts, snapshots, or bars."""
    research = OptionSurface(
        "SPX", "2026-09-24", (), "robinhood_mcp_research",
        Availability.AVAILABLE, evidence={
            "research_only": "true",
            "order_submission_enabled": "false",
        },
    )
    bars = tuple(
        __import__("option_bot.indicators", fromlist=["Bar"]).Bar(
            datetime(2026, 9, 23, 9, 30, tzinfo=ET) + __import__("datetime").timedelta(minutes=5 * index),
            Decimal("7680"), Decimal("7682"), Decimal("7678"), Decimal("7681"), 1000,
        )
        for index in range(24)
    )
    monkeypatch.setattr(
        SetupEvaluator,
        "evaluate",
        lambda self, symbol, indicators, surface, events, config: EvaluatedSetup(
            symbol, Decision.NO_TRADE, None, 60, 0, 70, None,
            ("NO_VALID_STRUCTURE",), f"scan:{symbol}",
        ),
    )
    monkeypatch.setattr(
        "option_bot.live_scan.IndicatorEngine.compute",
        lambda *args, **kwargs: IndicatorSnapshot(
            True, Decimal("7680"), Decimal("7679"), Decimal("7680"), Decimal("7679"),
            25, 40, 20, 0.5, Decimal("7682"), Decimal("7678"), Decimal("7683"),
            Decimal("7677"), 2, False, ema50=Decimal("7675"), ema50_slope=Decimal("0.5"),
        ),
    )

    def forbidden_transport(*_args, **_kwargs):
        raise AssertionError("Alpaca transport must not be called")

    results = evaluate_live_scan(
        symbols=("SPX",), trade_date="2026-09-24",
        as_of=datetime(2026, 9, 24, 10, 0, tzinfo=ET),
        paper_transport=forbidden_transport,
        market_transport=forbidden_transport,
        event_report={"scheduled_calendar_status": "AVAILABLE", "event_gate": "CLEAR"},
        evidence_engine=type("Engine", (), {"score": lambda *args: None})(),
        max_loss=Decimal("500"),
        trade_threshold=75, watch_threshold=55,
        research_surface_provider=lambda *_: research,
        research_bars_provider=lambda symbol, as_of: bars,
    )

    assert results[0].decision is Decision.NO_TRADE
    assert results[0].reason_codes == ("NO_VALID_STRUCTURE",)


def test_vertical_credit_with_16_percent_profit_to_loss_can_trade_without_25_percent_ev_gate() -> None:
    expiry = "2026-09-15"
    product = ProductMetadata("AAPL", 100, ExerciseStyle.AMERICAN, SettlementType.PHYSICAL, "16:00")
    candidate = TradeCandidate(
        "AAPL-CALL_CREDIT_SPREAD-0.25", "AAPL",
        (OptionLeg("AAPL-C340", OptionRight.CALL, TradeSide.SELL, Decimal("340"), expiry, 1),
         OptionLeg("AAPL-C345", OptionRight.CALL, TradeSide.BUY, Decimal("345"), expiry, 1)),
        product, Money(Decimal("0.68")), structure_type=StructureType.CALL_CREDIT_SPREAD,
        probability_of_profit=Decimal(".80"), probability_model_version="test-verified",
    )
    evaluator = SetupEvaluator(
        score=lambda *_: EvidenceBundle(True, 90, 20, 80, Decimal("1"), "v1", "hash", (), None, None),
        generate=lambda *_: (candidate,), trade_threshold=75, watch_threshold=55, max_loss=Decimal("500"),
    )
    indicators = IndicatorSnapshot(
        True, Decimal("200"), Decimal("199"), Decimal("200"), Decimal("199"),
        25, 40, 2, 1.2, Decimal("201"), Decimal("198"), Decimal("202"), Decimal("195"), 2, False,
    )
    result = evaluator.evaluate("AAPL", indicators, OptionSurface("AAPL", expiry, (), "indicative", Availability.AVAILABLE),
                                EventGateEvidence("AAPL", Availability.AVAILABLE, False, ()))
    assert result.expected_value is None  # No fabricated fixed-probability EV.
    assert result.decision is Decision.TRADE


def test_confirmed_same_day_stock_earnings_skips_chain_and_bar_work():
    calls = []
    results = evaluate_live_scan(
        symbols=("AAPL",), trade_date="2026-09-24",
        as_of=datetime(2026, 9, 24, 10, 0, tzinfo=ET),
        paper_transport=lambda *_: (_ for _ in ()).throw(AssertionError("paper transport")),
        market_transport=lambda *_: (_ for _ in ()).throw(AssertionError("market transport")),
        event_report={"trade_date": "2026-09-24",
                      "scheduled_calendar_status": "AVAILABLE", "event_gate": "CLEAR",
                      "earnings_calendar": {"source": "ROBINHOOD_MCP_RESEARCH",
                          "status": "AVAILABLE", "trade_date": "2026-09-24",
                          "results": [{"symbol": "AAPL", "report": {
                              "date": "2026-09-24", "timing": "pm", "verified": True}}]},
                      "symbols": [{"symbol": "AAPL"}]},
        evidence_engine=type("Engine", (), {"score": lambda *_: None})(), max_loss=Decimal("500"),
        trade_threshold=75, watch_threshold=55,
        research_surface_provider=lambda *_: (calls.append("chain") or OptionSurface(
            "AAPL", "2026-09-24", (), "robinhood_mcp_research", Availability.UNAVAILABLE,
            reason_codes=("EMPTY_OPTION_SURFACE",))),
        research_bars_provider=lambda *_: (calls.append("bars") or ()),
    )
    assert calls == []
    assert results[0].decision is Decision.NO_TRADE
    assert results[0].reason_codes == ("EARNINGS_REPORT_TODAY",)


def test_informational_risk_headlines_do_not_veto_scan(monkeypatch):
    """Catches a Robinhood-only scan still querying Alpaca contracts, snapshots, or bars."""
    research = OptionSurface(
        "SPX", "2026-09-24", (), "robinhood_mcp_research",
        Availability.AVAILABLE, evidence={
            "research_only": "true",
            "order_submission_enabled": "false",
        },
    )
    bars = tuple(
        __import__("option_bot.indicators", fromlist=["Bar"]).Bar(
            datetime(2026, 9, 23, 9, 30, tzinfo=ET) + __import__("datetime").timedelta(minutes=5 * index),
            Decimal("7680"), Decimal("7682"), Decimal("7678"), Decimal("7681"), 1000,
        )
        for index in range(24)
    )
    captured = []
    monkeypatch.setattr(
        SetupEvaluator,
        "evaluate",
        lambda self, symbol, indicators, surface, events, config: (captured.append(events) or EvaluatedSetup(
            symbol, Decision.NO_TRADE, None, 60, 0, 70, None,
            ("NO_VALID_STRUCTURE",), f"scan:{symbol}",
        )),
    )
    monkeypatch.setattr(
        "option_bot.live_scan.IndicatorEngine.compute",
        lambda *args, **kwargs: IndicatorSnapshot(
            True, Decimal("7680"), Decimal("7679"), Decimal("7680"), Decimal("7679"),
            25, 40, 20, 0.5, Decimal("7682"), Decimal("7678"), Decimal("7683"),
            Decimal("7677"), 2, False, ema50=Decimal("7675"), ema50_slope=Decimal("0.5"),
        ),
    )

    def forbidden_transport(*_args, **_kwargs):
        raise AssertionError("Alpaca transport must not be called")

    results = evaluate_live_scan(
        symbols=("SPX",), trade_date="2026-09-24",
        as_of=datetime(2026, 9, 24, 10, 0, tzinfo=ET),
        paper_transport=forbidden_transport,
        market_transport=forbidden_transport,
        event_report={"scheduled_calendar_status": "AVAILABLE", "event_gate": "CLEAR", "symbols": [{"symbol":"SPX", "headline_gate":"CLEAR", "reason_codes":[], "headlines":[{"title":"Cboe upgraded to Buy at TD Cowen on SPX contract", "published_at_et":"2026-10-05T16:28:07-04:00"}, {"title":"NVDA shares acquired by a wealth advisor"}, {"title":"Inflation forecast"}]}]},
        evidence_engine=type("Engine", (), {"score": lambda *args: None})(),
        max_loss=Decimal("500"),
        trade_threshold=75, watch_threshold=55,
        research_surface_provider=lambda *_: research,
        research_bars_provider=lambda symbol, as_of: bars,
    )

    assert results[0].decision is Decision.NO_TRADE
    assert results[0].reason_codes == ("NO_VALID_STRUCTURE",)

    assert captured[0].blocked is False
    assert "RISK_HEADLINE_REQUIRES_REVIEW" not in captured[0].reason_codes
