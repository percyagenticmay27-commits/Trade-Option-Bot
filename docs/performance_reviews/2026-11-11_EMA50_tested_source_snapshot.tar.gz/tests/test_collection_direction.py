"""Direction must narrow collection before quote requests and disable debit generation."""
from dataclasses import replace
from decimal import Decimal as D
import pytest
from test_directional_gate import snapshot
from test_structures import surface,evidence
from option_bot.collection_policy import collection_plan
from option_bot.structures import StructureConfig,StructureGenerator

@pytest.mark.parametrize("price,adx,chop,bias,rights",[
    ("110",25,40,"BULLISH",["put","call"]),
    ("90",25,40,"BEARISH",["call"]),
    ("100",15,60,"NEUTRAL",["put","call"]),
])
def test_collection_selects_only_directional_credit_side(price,adx,chop,bias,rights):
    s=replace(snapshot(),price=D(price),adx14=adx,chop14=chop,
              ema50=D("105") if D(price)>100 else D("95"),
              ema50_slope=D("0.5") if D(price)>100 else D("-0.5"))
    plan=collection_plan(s)
    assert plan["bias"]==bias
    assert plan["candidate_option_types"]==rights
    assert plan["directional_debit_enabled"] is (bias=="BULLISH")

def test_missing_direction_never_defaults_to_neutral_both_sides():
    p=collection_plan(replace(snapshot(),available=False))
    assert p["status"]=="DATA_UNAVAILABLE"
    assert p["candidate_option_types"]==[]

@pytest.mark.parametrize("bias,kind",[("BULLISH","PUT_CREDIT_SPREAD"),("BEARISH","CALL_CREDIT_SPREAD")])
def test_credit_only_generator_does_not_generate_directional_debit(bias,kind):
    config=StructureConfig(bias,D("330"),D("339"),D("331"),D("338"),D("500"),directional_credit_only=True)
    result=StructureGenerator.generate(surface(),evidence(),config)
    assert not any(c.structure_type.value.endswith("DEBIT_SPREAD") for c in result.candidates)
    assert not any("DEBIT" in r or "LONG_WING_UNAVAILABLE"==r for a in result.attempts for r in a.reason_codes)
    assert all(c.structure_type.value==kind for c in result.candidates)

def test_bullish_policy_collects_calls_and_generates_call_debit_alongside_put_credit():
    plan=collection_plan(replace(snapshot(),price=D("110"),adx14=25,chop14=40,ema50=D("105"),ema50_slope=D("0.5")))
    assert plan["candidate_option_types"]==["put","call"]
    assert plan["strategies"]==["PUT_CREDIT_SPREAD","CALL_DEBIT_SPREAD"]
    assert plan["directional_debit_enabled"] is True
    config=StructureConfig("BULLISH",D("90"),D("110"),D("90"),D("110"),D("500"),
                           directional_credit_only=True,call_debit_enabled=True)
    result=StructureGenerator.generate(surface(),evidence(),config)
    assert any(c.structure_type.value=="CALL_DEBIT_SPREAD" for c in result.candidates)

def test_bearish_policy_does_not_enable_put_debit():
    plan=collection_plan(replace(snapshot(),price=D("90"),adx14=25,chop14=40,ema50=D("95"),ema50_slope=D("-0.5")))
    assert plan["candidate_option_types"]==["call"]
    assert plan["strategies"]==["CALL_CREDIT_SPREAD"]
    assert plan["directional_debit_enabled"] is False
