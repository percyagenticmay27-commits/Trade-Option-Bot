"""Composition and report contracts for evidence-backed OPTION-001 scans."""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass, replace
from datetime import datetime, time, timedelta
from decimal import Decimal
from pathlib import Path
from typing import Any, Callable, Mapping, Sequence
from zoneinfo import ZoneInfo

from option_bot.domain import Decision, StructureType, TradeCandidate
from option_bot.evidence import EvidenceBundle
from option_bot.indicators import Bar, IndicatorEngine, IndicatorSnapshot
from option_bot.payoff import PayoffProfile
from option_bot.portfolio import PortfolioSelector, SelectableCandidate
from option_bot.providers.base import Availability, EventGateEvidence, OptionSurface
from option_bot.providers.normalization import normalize_option_surface, unavailable_surface
from option_bot.reporting import ReportBundle
from option_bot.structures import StructureConfig, StructureGenerator
from option_bot.probability import MINIMUM_PROBABILITY_OF_PROFIT
from option_bot.market_context import INDEX_MARKET_PROXIES, alignment_context, project_structure_config


ET = ZoneInfo("America/New_York")
Transport = Callable[[str, str, Mapping[str, Any], Mapping[str, Any] | None], tuple[int, Mapping[str, Any]]]


@dataclass(frozen=True)
class EvaluatedSetup:
    symbol: str
    decision: Decision
    candidate: SelectableCandidate | None
    direction_score: int | None
    range_score: int | None
    premium_score: int | None
    expected_value: Decimal | None
    reason_codes: tuple[str, ...]
    evidence_id: str
    trade_candidate: TradeCandidate | None = None
    execution_eligible: bool = False
    probability_of_profit: Decimal | None = None
    probability_model_version: str | None = None
    market_context: Mapping[str, Any] | None = None
    decision_details: Mapping[str, Any] | None = None
    technical_score_policy: str = "MINIMUM_SCORE_GATE"

    @classmethod
    def unavailable(cls, symbol: str, reasons: tuple[str, ...]) -> "EvaluatedSetup":
        return cls(symbol, Decision.DATA_UNAVAILABLE, None, None, None, None, None, reasons, f"unavailable:{symbol}")


def _payoff_for(candidate: TradeCandidate) -> PayoffProfile | None:
    if candidate.net_credit is not None:
        return PayoffProfile.evaluate(
            candidate.legs, candidate.net_credit.amount, candidate.product.multiplier
        )
    if candidate.net_debit is not None:
        return PayoffProfile.evaluate_debit(
            candidate.legs, candidate.net_debit.amount, candidate.product.multiplier
        )
    return None


class SetupEvaluator:
    """Turn normalized provider evidence into an auditable setup decision."""

    def __init__(
        self, *, score: Callable[[IndicatorSnapshot, OptionSurface, EventGateEvidence], EvidenceBundle],
        generate: Callable[[OptionSurface, EvidenceBundle, object], Sequence[TradeCandidate]],
        trade_threshold: int, watch_threshold: int, max_loss: Decimal,
        score_advisory: bool = False,
    ):
        self._score = score
        self._generate = generate
        self._trade_threshold = trade_threshold
        self._watch_threshold = watch_threshold
        self._max_loss = max_loss
        self._score_advisory = score_advisory

    def evaluate(
        self, symbol: str, indicators: IndicatorSnapshot, surface: OptionSurface,
        events: EventGateEvidence, structure_config: object | None = None,
    ) -> EvaluatedSetup:
        evidence = self._score(indicators, surface, events)
        evidence_id = f"{evidence.model_hash}:{symbol}"
        if not evidence.available:
            return EvaluatedSetup.unavailable(symbol, evidence.reason_codes)
        def setup_score(structure):
            if structure in {StructureType.CALL_CREDIT_SPREAD, StructureType.PUT_DEBIT_SPREAD}:
                return evidence.bearish_score if evidence.bearish_score is not None else evidence.direction_score
            if structure in {StructureType.PUT_CREDIT_SPREAD, StructureType.CALL_DEBIT_SPREAD}:
                return evidence.bullish_score if evidence.bullish_score is not None else evidence.direction_score
            return evidence.range_score

        generated = self._generate(surface, evidence, structure_config)
        candidates = tuple(generated.candidates) if hasattr(generated, "candidates") else tuple(generated)
        details = {"bias": getattr(structure_config, "bias", None),
                   "settings": asdict(structure_config) if hasattr(structure_config, "__dataclass_fields__") else {},
                   "indicators": asdict(indicators) if hasattr(indicators, "__dataclass_fields__") else None,
                   "evidence": asdict(evidence),
                   "contracts": [asdict(c) for c in surface.contracts],
                   "attempts": [asdict(a) for a in getattr(generated, "attempts", ())]}
        details = json.loads(json.dumps(details, default=lambda v: sorted(v) if isinstance(v, (set, frozenset)) else str(v)))
        scored: list[tuple[Decimal, TradeCandidate]] = []
        probability_rejections = set()
        for candidate in candidates:
            if candidate.probability_of_profit is None or not candidate.probability_model_version:
                probability_rejections.add("PROBABILITY_OF_PROFIT_UNAVAILABLE")
                continue
            if candidate.probability_of_profit < MINIMUM_PROBABILITY_OF_PROFIT:
                probability_rejections.add("PROBABILITY_OF_PROFIT_BELOW_MINIMUM")
                continue
            if candidate.structure_type is None:
                continue
            payoff = _payoff_for(candidate)
            if payoff is not None and payoff.maximum_loss.amount <= self._max_loss:
                rank = Decimal(setup_score(candidate.structure_type)) + Decimal(evidence.premium_score) / Decimal(10)
                scored.append((rank, candidate))
        if not scored:
            bias = getattr(structure_config, "bias", None)
            directional_score = (evidence.bearish_score if bias == "BEARISH" else evidence.bullish_score)
            if directional_score is None:
                directional_score = evidence.direction_score
            gate_score = evidence.range_score if bias == "NEUTRAL" else directional_score
            reasons = {"NO_VALID_STRUCTURE"} | probability_rejections
            if hasattr(generated, "attempts"):
                for attempt in generated.attempts:
                    reasons.update(attempt.reason_codes)
            decision = Decision.WATCH if gate_score >= self._watch_threshold else Decision.NO_TRADE
            if probability_rejections:
                decision = Decision.DATA_UNAVAILABLE if probability_rejections == {"PROBABILITY_OF_PROFIT_UNAVAILABLE"} else Decision.NO_TRADE
            return EvaluatedSetup(symbol, decision, None, directional_score, evidence.range_score, evidence.premium_score, None, tuple(sorted(reasons)), evidence_id, decision_details=details)
        rank, candidate = max(scored, key=lambda row: row[0])
        # Direction/regime and verified structure POP govern eligibility.
        # No fixed win/loss scenario is used as a veto or ranking tiebreaker.
        expected = None
        selected_score = setup_score(candidate.structure_type)
        decision = (Decision.TRADE if self._score_advisory or selected_score >= self._trade_threshold
                    else Decision.WATCH if selected_score >= self._watch_threshold else Decision.NO_TRADE)
        payoff = _payoff_for(candidate)
        premium_type = "CREDIT" if candidate.net_credit is not None else "DEBIT"
        entry_price = (
            candidate.net_credit.amount if candidate.net_credit is not None
            else candidate.net_debit.amount
        )
        selectable = SelectableCandidate(
            symbol, candidate.candidate_id, candidate.structure_type, rank,
            payoff.maximum_loss.amount, _exposure_group(symbol),
            maximum_profit=payoff.maximum_profit.amount,
            premium_type=premium_type, entry_price=entry_price,
        )
        reasons = () if decision is Decision.TRADE else ("SCORE_BELOW_THRESHOLD",)
        return EvaluatedSetup(symbol, decision, selectable, selected_score, evidence.range_score, evidence.premium_score, expected, reasons, evidence_id, trade_candidate=candidate, execution_eligible=surface.feed != "robinhood_mcp_research", probability_of_profit=candidate.probability_of_profit, probability_model_version=candidate.probability_model_version, technical_score_policy=("ADVISORY_DIRECTION_AND_RANKING" if self._score_advisory else "MINIMUM_SCORE_GATE"), decision_details=details)


def _resolve_option_surface(
    primary: OptionSurface,
    research: OptionSurface | Callable[[str, str, datetime], OptionSurface] | None,
    as_of: datetime | None = None,
) -> OptionSurface:
    """Use Alpaca when executable evidence is complete; otherwise use verified Robinhood research."""
    if primary.availability is Availability.AVAILABLE:
        return primary
    if callable(research):
        research = research(primary.symbol, primary.expiration, as_of or datetime.now(ET))
    if research is not None:
        evidence = research.evidence or {}
        if (
            research.availability is Availability.AVAILABLE
            and research.feed == "robinhood_mcp_research"
            and evidence.get("research_only") == "true"
            and evidence.get("order_submission_enabled") == "false"
        ):
            return research
    return primary


def _exposure_group(symbol: str) -> str:
    if symbol in {"NVDA", "GOOGL", "AAPL", "MSFT", "AMZN", "META", "AVGO"}:
        return "MEGA_CAP_TECH"
    if symbol in {"SPX", "XSP"}:
        return "SPX_XSP_INDEX"
    if symbol in {"DJX", "MRUT"}:
        return "US_INDEX"
    return symbol


def _market_history_start(as_of: datetime) -> datetime:
    """Return a premarket boundary with enough completed-session history for indicators."""
    observed = as_of.astimezone(ET)
    return (observed - timedelta(days=7)).replace(hour=4, minute=0, second=0, microsecond=0)


def _bars(payload: Mapping[str, Any]) -> tuple[Bar, ...]:
    raw = payload.get("bars", ())
    if isinstance(raw, Mapping):
        raw = next(iter(raw.values()), ())
    result = []
    for item in raw if isinstance(raw, list) else ():
        try:
            stamp = datetime.fromisoformat(str(item.get("t", item.get("timestamp"))).replace("Z", "+00:00")).astimezone(ET)
            result.append(Bar(stamp, Decimal(str(item.get("o", item.get("open")))), Decimal(str(item.get("h", item.get("high")))), Decimal(str(item.get("l", item.get("low")))), Decimal(str(item.get("c", item.get("close")))), int(item.get("v", item.get("volume")))))
        except (AttributeError, TypeError, ValueError):
            continue
    return tuple(sorted(result, key=lambda bar: bar.timestamp))


def _aggregate_15m(bars: Sequence[Bar]) -> tuple[Bar, ...]:
    buckets: dict[datetime, list[Bar]] = {}
    for bar in bars:
        minute = (bar.timestamp.minute // 15) * 15
        key = bar.timestamp.replace(minute=minute, second=0, microsecond=0)
        buckets.setdefault(key, []).append(bar)
    return tuple(Bar(key, rows[0].open, max(row.high for row in rows), min(row.low for row in rows), rows[-1].close, sum(row.volume for row in rows)) for key, rows in sorted(buckets.items()))


def _combined_chain(contracts_payload: Mapping[str, Any], snapshots_payload: Mapping[str, Any]) -> dict[str, Any]:
    contracts = contracts_payload.get("option_contracts", contracts_payload.get("contracts", ()))
    metadata = {str(row.get("symbol")): row for row in contracts if isinstance(row, Mapping)} if isinstance(contracts, list) else {}
    snapshots = snapshots_payload.get("snapshots", snapshots_payload.get("contracts", snapshots_payload.get("chain", {})))
    combined: dict[str, dict[str, Any]] = {}
    for symbol, snapshot in snapshots.items() if isinstance(snapshots, Mapping) else ():
        if not isinstance(snapshot, Mapping):
            continue
        contract = dict(metadata.get(str(symbol), {}))
        quote = snapshot.get("latestQuote", snapshot.get("latest_quote", {}))
        greeks = snapshot.get("greeks") or {}
        contract.update({
            "symbol": symbol, "latest_quote": {
                "bid_price": quote.get("bp", quote.get("bid_price")), "ask_price": quote.get("ap", quote.get("ask_price")),
                "bid_size": quote.get("bs", quote.get("bid_size", 0)), "ask_size": quote.get("as", quote.get("ask_size", 0)),
                "timestamp": quote.get("t", quote.get("timestamp")),
            },
            "greeks": {"delta": greeks.get("delta"), "gamma": greeks.get("gamma"), "theta": greeks.get("theta"), "vega": greeks.get("vega")},
            "implied_volatility": snapshot.get("impliedVolatility", snapshot.get("implied_volatility")),
        })
        combined[str(symbol)] = contract
    return {"contracts": combined, "feed": "indicative"}


def indicators_for_bars(bars, alignment_flags=None):
    alignment_flags = alignment_flags or {}
    if len(bars) < 20:
        indicators = IndicatorEngine.compute(bars, (), {})
    else:
        current_session = bars[-1].timestamp.date()
        prior_dates = sorted({row.timestamp.date() for row in bars if row.timestamp.date() < current_session})
        prior_session = tuple(row for row in bars if prior_dates and row.timestamp.date() == prior_dates[-1])
        volume_basis = prior_session or tuple(row for row in bars[:-1])
        average_volume = sum(row.volume for row in volume_basis) / max(1, len(volume_basis))
        context = {"average_volume": average_volume, **alignment_flags}
        if prior_session:
            context.update({"previous_high": max(row.high for row in prior_session), "previous_low": min(row.low for row in prior_session)})
        indicators = IndicatorEngine.compute(bars, _aggregate_15m(bars), context)
    return indicators


def evaluate_live_scan(
    *, symbols: Sequence[str], trade_date: str, as_of: datetime, paper_transport: Transport,
    market_transport: Transport, event_report: Mapping[str, Any], evidence_engine: object,
    max_loss: Decimal, trade_threshold: int, watch_threshold: int,
    research_surface_provider: Callable[[str, str, datetime], OptionSurface] | None = None,
    research_bars_provider: Callable[[str, datetime], Sequence[Bar]] | None = None,
    max_loss_for_symbol: Callable[[str], Decimal] | None = None,
    score_advisory: bool = False,
    directional_credit_only: bool = False,
    call_debit_enabled: bool = False,
    bollinger_condor: bool = False,
) -> tuple[EvaluatedSetup, ...]:
    """Read Alpaca evidence and evaluate every governed symbol without submitting orders."""
    if as_of.tzinfo is None:
        raise ValueError("scan time must be timezone-aware")
    from option_bot.scheduled_events import apply_scheduled_event_policy
    event_report = apply_scheduled_event_policy({**event_report, "trade_date": trade_date, "scan_as_of_et": as_of.isoformat()})
    start = _market_history_start(as_of)
    scheduled_available = event_report.get("scheduled_calendar_status") == "AVAILABLE"
    event_rows = {
        row.get("symbol"): row for row in event_report.get("symbols", ())
        if isinstance(row, Mapping) and row.get("symbol")
    }
    results = []
    for symbol in symbols:
        if not scheduled_available:
            results.append(EvaluatedSetup.unavailable(symbol, ("SCHEDULED_EVENT_GATE_UNAVAILABLE",)))
            continue
        if event_report.get("event_gate") == "BLOCKED":
            reasons = tuple(event_report.get("reason_codes") or ("SCHEDULED_EVENT_TODAY",))
            results.append(EvaluatedSetup(symbol, Decision.NO_TRADE, None, None, None, None, None, reasons, f"events:{symbol}"))
            continue
        symbol_events = event_rows.get(symbol, {})
        if symbol_events.get("earnings_gate") == "UNAVAILABLE":
            reasons = tuple(symbol_events.get("earnings_reason_codes") or ("EARNINGS_CALENDAR_UNAVAILABLE",))
            results.append(EvaluatedSetup.unavailable(symbol, reasons))
            continue
        if symbol_events.get("earnings_gate") == "BLOCKED":
            reasons = tuple(symbol_events.get("earnings_reason_codes") or ("EARNINGS_REPORT_TODAY",))
            results.append(EvaluatedSetup(symbol, Decision.NO_TRADE, None, None, None, None, None, reasons, f"news:{symbol}"))
            continue
        symbol_max_loss = max_loss_for_symbol(symbol) if max_loss_for_symbol else max_loss
        evaluator = SetupEvaluator(
            score=evidence_engine.score, generate=StructureGenerator.generate,
            trade_threshold=trade_threshold, watch_threshold=watch_threshold,
            max_loss=symbol_max_loss, score_advisory=score_advisory,
        )
        # Robinhood research is intentionally read first.  It supplies the opening
        # snapshot/context but never receives order authority.
        research_surface = (
            research_surface_provider(symbol, trade_date, datetime.now(ET))
            if research_surface_provider is not None else None
        )
        if research_bars_provider is not None:
            surface = research_surface or unavailable_surface(
                symbol, trade_date, "RESEARCH_SYMBOL_UNAVAILABLE"
            )
            bars = tuple(research_bars_provider(symbol, as_of))
        else:
            contract_status, contract_payload = paper_transport("GET", "/v2/options/contracts", {"underlying_symbols": symbol, "expiration_date": trade_date, "status": "active", "limit": 10000}, None)
            received_at = datetime.now(ET)
            contracts = (
                contract_payload.get("option_contracts", contract_payload.get("contracts", ()))
                if contract_status == 200 else ()
            )
            no_expiration = contract_status == 200 and not contracts
            if contract_status != 200:
                primary_surface = unavailable_surface(
                    symbol, trade_date, f"CONTRACTS_HTTP_{contract_status}"
                )
            elif no_expiration:
                primary_surface = unavailable_surface(
                    symbol, trade_date, "NO_EXPIRATION_TODAY"
                )
            else:
                snapshot_status, snapshot_payload = market_transport("GET", f"/v1beta1/options/snapshots/{symbol}", {"expiration_date": trade_date, "feed": "indicative", "limit": 1000}, None)
                if snapshot_status != 200:
                    primary_surface = unavailable_surface(
                        symbol, trade_date, f"OPTION_SNAPSHOT_HTTP_{snapshot_status}"
                    )
                else:
                    primary_surface = normalize_option_surface(
                        symbol,
                        trade_date,
                        _combined_chain(contract_payload, snapshot_payload),
                        received_at,
                    )
            surface = _resolve_option_surface(primary_surface, research_surface)
            market_symbol = INDEX_MARKET_PROXIES.get(symbol, symbol)
            bars_status, bars_payload = market_transport("GET", f"/v2/stocks/{market_symbol}/bars", {"timeframe": "5Min", "start": start.isoformat(), "end": as_of.isoformat(), "feed": "iex", "adjustment": "raw", "limit": 1000}, None)
            bars = _bars(bars_payload) if bars_status == 200 else ()
        if surface.availability is not Availability.AVAILABLE:
            results.append(EvaluatedSetup.unavailable(symbol, surface.reason_codes))
            continue
        context_audit = {}
        alignment_flags = {}
        strict_context = (surface.evidence or {}).get("market_context_required") == "true"
        raw_context = {}
        if strict_context:
            try:
                raw_context = json.loads(surface.evidence["market_context_json"])
                alignment_flags, alignment_audit = alignment_context(raw_context, as_of)
                context_audit["alignment"] = alignment_audit
            except (KeyError, TypeError, ValueError) as exc:
                results.append(EvaluatedSetup.unavailable(symbol, (str(exc),)))
                continue
        indicators = indicators_for_bars(bars, alignment_flags)
        events = EventGateEvidence(symbol, Availability.AVAILABLE if scheduled_available and event_report.get("event_gate") != "UNAVAILABLE" else Availability.UNAVAILABLE, event_report.get("event_gate") == "BLOCKED", tuple(event_report.get("scheduled_events", ())), tuple(event_report.get("reason_codes", ())))
        if not indicators.available or surface.availability is not Availability.AVAILABLE:
            reasons = indicators.reason_codes + surface.reason_codes
            results.append(EvaluatedSetup.unavailable(symbol, reasons))
            continue
        from option_bot.collection_policy import collection_plan
        plan = collection_plan(indicators)
        if plan['status']!='AVAILABLE':
            results.append(replace(EvaluatedSetup.unavailable(symbol,(plan['reason'],)),
                                   market_context={'collection_direction':plan}))
            continue
        bias = plan["bias"]
        context_audit["collection_direction"] = json.loads(json.dumps(plan, default=str))
        config = StructureConfig(bias, min(indicators.opening_range_low, indicators.previous_low), max(indicators.opening_range_high, indicators.previous_high), indicators.price - Decimal(str(indicators.atr14)), indicators.price + Decimal(str(indicators.atr14)), symbol_max_loss, landing_zone=indicators.price, directional_credit_only=directional_credit_only, call_debit_enabled=call_debit_enabled)
        if strict_context:
            from option_bot.intraday_clearance import clearance_levels
            try:
                levels = clearance_levels(bars, as_of, bias)
                context_audit["intraday_clearance"] = json.loads(json.dumps({
                    **levels, "source_symbol": surface.evidence["bar_source_symbol"],
                    "previous_high_context_only": indicators.previous_high,
                    "previous_low_context_only": indicators.previous_low,
                    "atr14": indicators.atr14,
                }, default=str))
                config = replace(config,
                    support=levels["support"] if levels["support"] is not None else config.support,
                    resistance=levels["resistance"] if levels["resistance"] is not None else config.resistance)
            except (ValueError, KeyError) as exc:
                results.append(replace(EvaluatedSetup.unavailable(symbol, (str(exc),)), market_context=context_audit))
                continue
        if bollinger_condor and symbol in {"SPX", "XSP"} and bias == "NEUTRAL":
            from option_bot.bollinger import condor_bands
            try:
                band = condor_bands(bars, as_of)
                config = replace(config, condor_lower=band["condor_lower"], condor_upper=band["condor_upper"])
                context_audit["bollinger"] = json.loads(json.dumps(band, default=str))
            except ValueError as exc:
                results.append(replace(EvaluatedSetup.unavailable(symbol, (str(exc),)), market_context=context_audit))
                continue
        if strict_context:
            try:
                config, projection = project_structure_config(config, symbol,
                    surface.evidence["bar_source_symbol"], raw_context, as_of)
                context_audit["technical_projection"] = projection
                if "bollinger" in context_audit:
                    context_audit["bollinger"].update(target_symbol=symbol, source_symbol=surface.evidence["bar_source_symbol"], projected_condor_lower=str(config.condor_lower), projected_condor_upper=str(config.condor_upper), projection_ratio=projection["ratio"])
            except (KeyError, TypeError, ValueError) as exc:
                results.append(replace(EvaluatedSetup.unavailable(symbol, (str(exc),)), market_context=context_audit))
                continue
        results.append(replace(evaluator.evaluate(symbol, indicators, surface, events, config),
                               market_context=context_audit or None,
                               technical_score_policy=("ADVISORY_DIRECTION_AND_RANKING" if score_advisory else "MINIMUM_SCORE_GATE")))
    return tuple(results)


def _write(path: Path, payload: dict) -> None:
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def build_scan_report(
    *, trade_date: str, symbols: Sequence[str], evaluations: Sequence[EvaluatedSetup],
    output_dir: Path, render: bool = True, order_submission_enabled: bool = False,
    paper_result: dict | None = None,
) -> ReportBundle:
    by_symbol = {item.symbol: item for item in evaluations}
    original_order = {symbol: index for index, symbol in enumerate(symbols)}
    ordered = [by_symbol.get(symbol) or EvaluatedSetup.unavailable(symbol, ("EVALUATION_MISSING",)) for symbol in symbols]
    def ranking_key(item: EvaluatedSetup) -> tuple[Decimal, int]:
        score = item.candidate.rank_score if item.candidate else Decimal(max(item.direction_score or 0, item.range_score or 0))
        if item.decision is Decision.DATA_UNAVAILABLE:
            score = Decimal("-1")
        return (-score, original_order[item.symbol])
    ordered.sort(key=ranking_key)
    rows = []
    qualified: list[SelectableCandidate] = []
    for rank, item in enumerate(ordered, 1):
        symbol = item.symbol
        candidate = item.candidate
        if item.decision is Decision.TRADE and candidate is not None:
            qualified.append(candidate)
        rows.append({
            "rank": rank, "symbol": symbol,
            "status": "PENDING" if item.decision is Decision.DATA_UNAVAILABLE else "EVALUATED",
            "decision": item.decision.value,
            "structure": candidate.structure_type.value if candidate else None,
            "direction_score": item.direction_score, "range_score": item.range_score,
            "premium_score": item.premium_score,
            "technical_score_policy": item.technical_score_policy,
            "decision_details": item.decision_details,
            "premium_type": candidate.premium_type if candidate else None,
            "entry_price": str(candidate.entry_price) if candidate and candidate.entry_price is not None else None,
            "maximum_profit": str(candidate.maximum_profit) if candidate and candidate.maximum_profit is not None else None,
            "maximum_loss": str(candidate.maximum_loss) if candidate else None,
            "expected_value": str(item.expected_value) if item.expected_value is not None else None,
            "probability_of_profit": str(item.probability_of_profit) if item.probability_of_profit is not None else None,
            "probability_model_version": item.probability_model_version,
            "market_context": item.market_context,
            "minimum_probability_of_profit": "0.75",
            "reason": ", ".join(item.reason_codes) if item.reason_codes else "Qualified by current evidence.",
            "reason_codes": list(item.reason_codes), "evidence_id": item.evidence_id,
        })
    selection = PortfolioSelector().select(qualified, (), Decimal("0"), 0)
    selected = [{
        "symbol": candidate.symbol, "candidate_id": candidate.candidate_id,
        "structure": candidate.structure_type.value,
        "premium_type": candidate.premium_type,
        "entry_price": str(candidate.entry_price) if candidate.entry_price is not None else None,
        "maximum_profit": str(candidate.maximum_profit) if candidate.maximum_profit is not None else None,
        "maximum_loss": str(candidate.maximum_loss),
        "rank_score": str(candidate.rank_score),
        "probability_of_profit": next((row["probability_of_profit"] for row in rows if row["symbol"] == candidate.symbol), None),
        "probability_model_version": next((row["probability_model_version"] for row in rows if row["symbol"] == candidate.symbol), None),
    } for candidate in selection.selected]
    unavailable = sum(row["decision"] == Decision.DATA_UNAVAILABLE.value for row in rows)
    summary = {
        "paper_only": True, "module_id": "OPTION-001", "strategy_type": "0DTE_OPTIONS",
        "market_data_provider": "ROBINHOOD_MCP_RESEARCH",
        "paper_execution_mode": "LOCAL_SIMULATION",
        "live_trading_enabled": False,
        "broker_execution_enabled": False,
        "order_submission_enabled": False,
        "trade_date": trade_date, "market_session": "CURRENT",
        "best_neutral": next((row["symbol"] for row in rows if row["structure"] in {"IRON_CONDOR", "IRON_BUTTERFLY", "DEBIT_BUTTERFLY"}), None),
        "best_directional": next((row["symbol"] for row in rows if row["structure"] in {"PUT_CREDIT_SPREAD", "CALL_CREDIT_SPREAD", "CALL_DEBIT_SPREAD", "PUT_DEBIT_SPREAD"}), None),
        "selected_count": len(selected), "open_count": 0, "completed_count": 0,
        "health": "PENDING" if unavailable == len(rows) else ("DEGRADED" if unavailable else "HEALTHY"),
        "rejected_candidates": [row for row in rows if row["decision"] == Decision.NO_TRADE.value],
    }
    positions = {
        "paper_only": True,
        "market_data_provider": "ROBINHOOD_MCP_RESEARCH",
        "paper_execution_mode": "LOCAL_SIMULATION",
        "live_trading_enabled": False,
        "broker_execution_enabled": False,
        "order_submission_enabled": False,
        "trade_date": trade_date,
        "selected": selected,
        "open": [],
        "completed": [],
    }
    experience = {
        "paper_only": True,
        "order_submission_enabled": False,
        "trade_date": trade_date,
        "mode": "LOCAL_PAPER_SIMULATION",
        "ranking_influence": False,
        "symbols": [],
    }
    if paper_result is not None:
        apply_paper_result(summary, positions, paper_result)
    bundle = ReportBundle(summary, rows, positions, experience)
    output_dir.mkdir(parents=True, exist_ok=True)
    _write(output_dir / "option_001_summary.json", summary)
    _write(output_dir / "option_001_leaderboard.json", {
        "paper_only": True,
        "market_data_provider": "ROBINHOOD_MCP_RESEARCH",
        "order_submission_enabled": False,
        "trade_date": trade_date,
        "leaderboard": rows,
    })
    _write(output_dir / "option_001_positions.json", positions)
    _write(output_dir / "option_001_experience.json", experience)
    if render:
        from option_bot.dashboard import DashboardRenderer
        (output_dir / "option_001_dashboard.html").write_text(DashboardRenderer().render(bundle), encoding="utf-8")
    return bundle


def apply_paper_result(summary, positions, result):
    positions.update(result)
    summary.update({key: result[key] for key in (
        "generated_at_utc", "daily_entry_count", "daily_defined_loss", "daily_risk_remaining",
        "daily_realized_pnl", "realized_pnl", "paper_execution_status", "paper_execution_reasons",
        "execution_rejections", "paper_only", "live_trading_enabled", "broker_execution_enabled",
        "order_submission_enabled")})
    summary["settlement_pending_count"] = result.get("settlement_pending_count", 0)
    summary.update(open_count=len(result["open"]), completed_count=len(result["completed"]),
                   selected_count=len(result["selected"]), new_paper_event_count=len(result["new_events"]))
    if result["paper_execution_status"] == "DEGRADED":
        summary["health"] = "DEGRADED"


def refresh_paper_reports(output_dir, result):
    output_dir.mkdir(parents=True, exist_ok=True)
    def read(name, default):
        path = output_dir / name
        return json.loads(path.read_text()) if path.exists() else default
    summary = read("option_001_summary.json", {"module_id": "OPTION-001", "health": "PENDING", "market_session": "MANAGEMENT_ONLY", "best_neutral": None, "best_directional": None})
    positions = read("option_001_positions.json", {})
    leaderboard = read("option_001_leaderboard.json", {"leaderboard": []})
    experience = read("option_001_experience.json", {"symbols": []})
    summary["trade_date"] = result["trade_date"]
    apply_paper_result(summary, positions, result)
    _write(output_dir / "option_001_summary.json", summary)
    _write(output_dir / "option_001_positions.json", positions)
    bundle = ReportBundle(summary, leaderboard["leaderboard"], positions, experience)
    from option_bot.dashboard import DashboardRenderer
    (output_dir / "option_001_dashboard.html").write_text(DashboardRenderer().render(bundle), encoding="utf-8")
    return bundle
